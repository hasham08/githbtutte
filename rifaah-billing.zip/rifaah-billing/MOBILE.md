# Web, Android and iOS apps

One code base gives you all three.

## 1. Web (already works)
`npm install` then `npm run build`. Upload the **contents** of `dist` to `public_html`.

## 2. Install as an app from the website (PWA) - Android and iPhone
Needs the site on **https**.
- **Android (Chrome):** open the site, menu (three dots) > **Install app** / **Add to Home screen**.
- **iPhone (Safari):** open the site, Share button > **Add to Home Screen**.
It then opens full screen with the Rifaah logo, like a normal app, and keeps working offline for pages already opened.

## 3. Real store apps (APK / AAB / IPA) with Capacitor
Needs tools that only run on your own computer.
```
npm install
npm run cap:add:android      # once  (needs Android Studio + JDK 17)
npm run cap:add:ios          # once  (needs a Mac with Xcode)
npm run cap:sync             # after every change: builds web and copies to apps
npm run cap:android          # opens Android Studio  -> Build > Generate Signed Bundle / APK
npm run cap:ios              # opens Xcode           -> Product > Archive
```
Play Store needs a Google Play developer account (one-time US$25). App Store needs an Apple Developer account (US$99 per year).
App id is `com.rifaah.billing` (change in `capacitor.config.json`).

Note: data is stored inside each phone/browser (localStorage). To share invoices between devices a backend/database is needed.
