# Rifaah Group – Billing Software (React + Vite)

## Run
```
npm install
npm run dev        # development at http://localhost:5173
npm run build      # production files in /dist
npm run preview    # test the production build
```
Upload the contents of `dist/` to any web host (Netlify, Vercel, cPanel hosting).

## Default login
Admin: `admin` / `admin123` – change it in Settings > Change admin login.

## Structure
- `src/lib.js` – seed data, saved-data loader, kg / mound / rate calculation, permission list
- `src/App.jsx` – login, menu, pages, role and permission checks
- `src/components/` – InvTable, NewInvoice, InvoiceSheet (print / PDF), Customers, Suppliers, Products, Categories, Employees, AdminAccount, Settings
- `src/assets/logo.webp` – Rifaah Group logo

## Important
Data and passwords are stored in the browser (localStorage) only. Before real use, add a backend
(for example Firebase Auth + Firestore, or Node/Express + a database) with hashed passwords and
server-side permission checks. The place to connect it is `load()` in `src/lib.js` and the `upd()`
function in `src/App.jsx`.
