import { useState, useEffect } from 'react'
import { KEY, seed, load, sub, netKg } from './lib.js'
import LOGO from './assets/logo.webp'
import Ic from './components/Ic'
import InvTable from './components/InvTable'
import NewInvoice from './components/NewInvoice'
import Customers from './components/Customers'
import Products from './components/Products'
import Categories from './components/Categories'
import Suppliers from './components/Suppliers'
import Employees from './components/Employees'
import InvoiceSheet from './components/InvoiceSheet'
import ResetAll from './components/ResetAll'
import AdminAccount from './components/AdminAccount'
import Settings from './components/Settings'

export default function App(){
  const [db,setDb]=useState(load);
  const sess0=(()=>{try{const x=JSON.parse(localStorage.getItem('billdesk-session')||'null');if(!x)return null;const d=load();if(x.role==='admin')return x;if(x.role==='user'&&d.employees.some(e=>e.id===x.uid))return x}catch(e){}return null})();
  const [role,setRole]=useState(sess0?sess0.role:null);
  const [uid,setUid]=useState(sess0&&sess0.uid?sess0.uid:1);
  useEffect(()=>{try{if(role)localStorage.setItem('billdesk-session',JSON.stringify({role,uid}));else localStorage.removeItem('billdesk-session')}catch(e){}},[role,uid]);
  const [page,setPage]=useState('dash');
  const [toast,setToast]=useState('');
  const [unit,setUnit]=useState('kg');
  const [catf,setCatf]=useState('');
  const [view,setView]=useState(null);
  const [lu,setLu]=useState(''),[lp,setLp]=useState(''),[lerr,setLerr]=useState('');
  useEffect(()=>{try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){}document.documentElement.style.setProperty('--brand',db.settings.brand)},[db]);
  const say=m=>{setToast(m);setTimeout(()=>setToast(''),5000)};
  const cur=db.settings.currency;
  const kpm=db.settings.kpm||40;
  const total=i=>sub(i,kpm)*(1+db.settings.tax/100);
  const fw=n=>unit==='kg'?n.toLocaleString('en-IN',{maximumFractionDigits:2})+' kg':(n/kpm).toLocaleString('en-IN',{maximumFractionDigits:2})+' mound';
  const wt=i=>fw(netKg(i,kpm));
  const wtAll=l=>fw(l.reduce((a,i)=>a+netKg(i,kpm),0));
  const money=n=>cur+Math.round(n).toLocaleString('en-IN');
  const cname=id=>(db.customers.find(c=>c.id===id)||{}).name||'—';
  const sname=id=>id?((db.suppliers.find(x=>x.id===id)||{}).name||'—'):'—';
  const ename=id=>id===0?'Admin':(db.employees.find(e=>e.id===id)||{}).name||'—';
  const upd=(f)=>setDb(d=>f(d));
  const signIn=()=>{const u=lu.trim().toLowerCase();if(u===db.admin.username&&lp===db.admin.password){setRole('admin');setPage('dash');setLerr('');setLp('');return}const m=db.employees.find(x=>x.username.toLowerCase()===u&&x.password===lp);if(m){setRole('user');setUid(m.id);setPage('dash');setLerr('');setLp('')}else setLerr('Wrong username or password.')};

  if(!role) return (
    <div className="login">
      <div className="brand big"><img src={LOGO} alt="Rifaah Group Pakistan logo"/></div>
      <div className="panel">
        <h2>Sign in</h2>
        <label>Username</label><input style={{width:'100%'}} autoComplete="username" value={lu} onChange={e=>setLu(e.target.value)}/><label style={{marginTop:8}}>Password</label><input style={{width:'100%'}} type="password" autoComplete="current-password" value={lp} onChange={e=>setLp(e.target.value)} onKeyDown={e=>e.key==='Enter'&&signIn()}/>{lerr&&<p role="alert" style={{color:'var(--over)',margin:'8px 0 0'}}>{lerr}</p>}
        
        <button className="btn" onClick={signIn}>Sign in</button>
      </div>
      
    </div>);

  const isAdmin=role==='admin';
  const me=db.employees.find(e=>e.id===uid)||{perms:[]};
  const can=p=>isAdmin||(me.perms||[]).includes(p);
  const viewAll=can('inv.all');
  const invs=viewAll?db.invoices:db.invoices.filter(i=>i.by===uid);
  const nav=isAdmin?[['dash','Dashboard'],['inv','Invoices'],['new','New invoice'],['cus','Customers'],['prod','Products'],['sup','Suppliers'],['cat','Categories'],['emp','Employees'],['set','Settings']]:[['dash','My dashboard'],...(can('inv')?[['inv','Invoices']]:[]),...(can('inv.add')?[['new','New invoice']]:[]),...(can('cus')?[['cus','Customers']]:[]),...(can('prod')?[['prod','Products']]:[]),...(can('sup')?[['sup','Suppliers']]:[]),...(can('cat')?[['cat','Categories']]:[])];

  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><img src={LOGO} alt="Rifaah Group Pakistan logo"/></div>
        {nav.map(([k,l])=><button key={k} className={'nav'+(page===k?' on':'')} onClick={()=>setPage(k)}><Ic n={k}/><span>{l}</span></button>)}
        <button className="nav" onClick={()=>setRole(null)}><Ic n="out"/><span>Sign out</span></button>
      </aside>
      <main className="main">
        <div className="top">
          <h1>{db.settings.company}{!isAdmin&&' · '+ename(uid)}</h1>
          <span style={{color:'var(--mute)',display:'flex',gap:8,alignItems:'center'}}>{isAdmin?'Admin panel':'Employee dashboard'}<select aria-label="Weight unit" value={unit} onChange={e=>setUnit(e.target.value)}><option value="kg">Show kg</option><option value="mound">Show mound</option></select></span>
        </div>

        {page==='dash'&&<>
          <div className="stats">
            <div className="stat"><span>Total amount</span><b>{money(invs.reduce((a,i)=>a+total(i),0))}</b></div>
            <div className="stat"><span>Net weight</span><b>{wtAll(invs)}</b></div>
            <div className="stat"><span>Invoices</span><b>{invs.length}</b></div>
          </div>
          <div className="panel"><h2>Recent invoices</h2>
            <InvTable invs={invs.slice(-5).reverse()} {...{money,total,cname,isAdmin,wt,wtAll,ename,sname,onView:setView,canPrint:can('inv.print'),canDel:can('inv.del')}} /></div>
        </>}

        {page==='inv'&&<div className="panel"><h2>{viewAll?'All invoices':'Your invoices'}</h2>
          <div className="row"><select aria-label="Filter by category" value={catf} onChange={e=>setCatf(e.target.value)}><option value="">All categories</option>{[...new Set(db.products.map(p=>p.cat))].map(k=><option key={k} value={k}>{k}</option>)}</select></div>
          <InvTable invs={[...invs].filter(i=>!catf||i.items.some(x=>x.cat===catf)).reverse()} {...{money,total,cname,isAdmin,wt,wtAll,ename,sname,onView:setView,canPrint:can('inv.print'),canDel:can('inv.del')}} onDelete={id=>{upd(d=>({...d,invoices:d.invoices.filter(i=>i.id!==id)}));say('Invoice deleted')}} /></div>}

        {page==='new'&&can('inv.add')&&<NewInvoice db={db} money={money} fixed={null} canCust={can('inv.cust')} canSupp={can('inv.supp')} canNewCust={true} canNewSupp={true} onNewCust={(name,cat)=>{const id=Date.now();upd(d=>({...d,customers:[...d.customers,{id,name,email:'',cat:cat||''}]}));say('Customer added');return id}} onNewSupp={(name,cat)=>{const id=Date.now()+1;upd(d=>({...d,suppliers:[...d.suppliers,{id,name,phone:'',cat:cat||''}]}));say('Supplier added');return id}} kpm={kpm} onSave={inv=>{upd(d=>({...d,invoices:[...d.invoices,{...inv,by:isAdmin?0:uid}]}));say('Invoice created');setPage('inv')}} />}

        {page==='cus'&&can('cus')&&<Customers canAdd={can('cus.add')} db={db} invs={invs} money={money} unit={unit} kpm={kpm} onDel={id=>{upd(d=>({...d,customers:d.customers.filter(x=>x.id!==id)}));say('Customer deleted')}} onAdd={c=>{upd(d=>({...d,customers:d.customers.some(x=>x.id===c.id)?d.customers.map(x=>x.id===c.id?{...x,...c}:x):[...d.customers,c]}));say('Customer saved')}} />}

        {isAdmin&&page==='emp'&&<Employees db={db} onAdd={e=>{if(db.employees.some(m=>m.username.toLowerCase()===e.username.toLowerCase())||e.username.toLowerCase()===db.admin.username){say('Username already used');return false}upd(d=>({...d,employees:[...d.employees,e]}));say('Employee login created')}} onDel={id=>{upd(d=>({...d,employees:d.employees.filter(m=>m.id!==id)}));say('Employee deleted')}} onUpdate={e=>{if(db.employees.some(m=>m.id!==e.id&&m.username.toLowerCase()===e.username.toLowerCase())||e.username.toLowerCase()===db.admin.username){say('Username already used');return false}upd(d=>({...d,employees:d.employees.map(m=>m.id===e.id?{...m,...e}:m)}));say('Employee updated')}} onPass={id=>{const p=Math.random().toString(36).slice(2,8);upd(d=>({...d,employees:d.employees.map(m=>m.id===id?{...m,password:p}:m)}));say('New password: '+p)}} />}

        {page==='cat'&&can('cat')&&<Categories cats={db.cats} can={can} usage={(k,c)=>db[k==='customer'?'customers':'suppliers'].filter(r=>r.cat===c).length} onChange={(k,list,ren)=>{upd(d=>{const x={...d,cats:{...d.cats,[k]:list}};if(ren){const key=k==='customer'?'customers':'suppliers';x[key]=d[key].map(r=>r.cat===ren[0]?{...r,cat:ren[1]}:r)}return x});say('Categories saved')}} />}

        {page==='prod'&&can('prod')&&<Products canEdit={can('prod.edit')} canDel={can('prod.del')} db={db} onSave={p=>{upd(d=>({...d,products:d.products.some(x=>x.id===p.id)?d.products.map(x=>x.id===p.id?p:x):[...d.products,p]}));say('Product saved')}} onDel={id=>{upd(d=>({...d,products:d.products.filter(x=>x.id!==id)}));say('Product deleted')}} />}

        {page==='sup'&&can('sup')&&<Suppliers canAdd={can('sup.add')} db={db} invs={invs} money={money} unit={unit} kpm={kpm} onDel={id=>{upd(d=>({...d,suppliers:d.suppliers.filter(x=>x.id!==id)}));say('Supplier deleted')}} onAdd={s=>{upd(d=>({...d,suppliers:d.suppliers.some(x=>x.id===s.id)?d.suppliers.map(x=>x.id===s.id?{...x,...s}:x):[...d.suppliers,s]}));say('Supplier saved')}} />}

        {isAdmin&&page==='set'&&<ResetAll onReset={mode=>{setDb(d=>mode==='sample'?{...JSON.parse(JSON.stringify(seed)),admin:d.admin}:{settings:{...seed.settings},employees:[],customers:[],invoices:[],suppliers:[],products:[],cats:{customer:[],supplier:[]},admin:d.admin,printMig:true,csMig:true,paidMig:true});setPage('dash');say(mode==='sample'?'Software reset with sample data':'Software reset: all data erased')}} />}

        {isAdmin&&page==='set'&&<AdminAccount admin={db.admin} employees={db.employees} onSave={a=>{upd(d=>({...d,admin:a}));say('Admin login updated')}} />}

        {isAdmin&&page==='set'&&<Settings s={db.settings} onSave={s=>{upd(d=>({...d,settings:s}));say('Settings saved')}} />}
      </main>
      {view&&<InvoiceSheet inv={db.invoices.find(i=>i.id===view)} db={db} money={money} kpm={kpm} cname={cname} ename={ename} onClose={()=>setView(null)}/>}
      {toast&&<div className="toast" role="status">{toast}</div>}
    </div>);
}
