import { useState } from 'react'

export default function AdminAccount({admin,employees,onSave}){
  const [u,setU]=useState(admin.username),[cp,setCp]=useState(''),[np,setNp]=useState(''),[rp,setRp]=useState(''),[er,setEr]=useState('');
  const go=()=>{if(cp!==admin.password)return setEr('Current password is wrong.');if(!u.trim())return setEr('Enter a username.');if(employees.some(m=>m.username.toLowerCase()===u.trim().toLowerCase()))return setEr('That username is used by an employee.');if(np.length<6)return setEr('New password must be at least 6 characters.');if(np!==rp)return setEr('New passwords do not match.');setEr('');onSave({username:u.trim().toLowerCase(),password:np});setCp('');setNp('');setRp('')};
  return <div className="panel"><h2>Change admin login</h2>
    <div className="row"><div style={{flex:'1 1 160px'}}><label>Admin username</label><input style={{width:'100%'}} value={u} onChange={e=>setU(e.target.value)}/></div>
    <div style={{flex:'1 1 160px'}}><label>Current password</label><input style={{width:'100%'}} type="password" autoComplete="current-password" value={cp} onChange={e=>setCp(e.target.value)}/></div>
    <div style={{flex:'1 1 160px'}}><label>New password (min 6)</label><input style={{width:'100%'}} type="password" autoComplete="new-password" value={np} onChange={e=>setNp(e.target.value)}/></div>
    <div style={{flex:'1 1 160px'}}><label>Repeat new password</label><input style={{width:'100%'}} type="password" autoComplete="new-password" value={rp} onChange={e=>setRp(e.target.value)}/></div></div>
    {er&&<p role="alert" style={{color:'var(--over)',margin:'0 0 10px'}}>{er}</p>}
    <button className="btn" onClick={go}>Update admin login</button></div>;
}
