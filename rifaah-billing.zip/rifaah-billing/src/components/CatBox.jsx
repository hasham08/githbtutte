import { useState } from 'react'

export default function CatBox({k,title,list,usage,onChange}){
  const [v,setV]=useState(''),[ed,setEd]=useState(null),[cf,setCf]=useState(null),[er,setEr]=useState('');
  const save=()=>{const t=v.trim();if(!t)return;if(list.some(c=>c.toLowerCase()===t.toLowerCase()&&c!==ed))return setEr('Category already exists.');setEr('');if(ed)onChange(k,list.map(c=>c===ed?t:c),[ed,t]);else onChange(k,[...list,t]);setV('');setEd(null)};
  return <div className="panel"><h2>{title}</h2>
    <div className="row"><input placeholder="Category name" value={v} onChange={e=>setV(e.target.value)} onKeyDown={e=>e.key==='Enter'&&save()}/><button className="btn" onClick={save}>{ed?'Save changes':'Add category'}</button>{ed&&<button className="btn ghost" onClick={()=>{setEd(null);setV('');setEr('')}}>Cancel</button>}</div>
    {er&&<p role="alert" style={{color:'var(--over)',margin:'0 0 8px'}}>{er}</p>}
    <div className="wrap"><table><thead><tr><th>Category</th><th>Used by</th><th></th></tr></thead><tbody>
      {list.map(c=>{const u=usage(k,c);return <tr key={c}><td>{c}</td><td>{u}</td><td><button className="btn ghost sm" onClick={()=>{setEd(c);setV(c);setCf(null)}}>Edit</button> {u>0?<span style={{color:'var(--mute)',fontSize:13}}>in use, cannot delete</span>:cf===c?<><button className="btn sm" style={{background:'var(--over)'}} onClick={()=>{onChange(k,list.filter(x=>x!==c));setCf(null)}}>Confirm delete</button> <button className="btn ghost sm" onClick={()=>setCf(null)}>Cancel</button></>:<button className="btn ghost sm" onClick={()=>setCf(c)}>Delete</button>}</td></tr>})}
    </tbody></table></div></div>;
}
