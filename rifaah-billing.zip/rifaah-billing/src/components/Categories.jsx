import CatBox from './CatBox'

export default function Categories({cats,can,usage,onChange}){
  const L=[['customer','Customer categories','cat.cust'],['supplier','Supplier categories','cat.supp']].filter(x=>can(x[2]));
  return L.length?<>{L.map(([k,t])=><CatBox key={k} k={k} title={t} list={cats[k]||[]} usage={usage} onChange={onChange}/>)}</>:<div className="panel">No category actions have been given to you.</div>;
}
