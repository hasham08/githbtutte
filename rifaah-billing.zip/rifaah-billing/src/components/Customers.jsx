import { useState } from 'react'
import { sub, netKg, fmtDate } from '../lib.js'

export default function Customers({db,onAdd,onDel,canAdd,invs,money,unit,kpm}){
  const [cf,setCf]=useState(null);
  const [fc,setFc]=useState(''),[ed,setEd]=useState(null),[sel,setSel]=useState(null);
  const [n,setN]=useState(''),[e,setE]=useState(''),[a,setA]=useState(''),[cat,setCat]=useState('');
  const clr=()=>{setEd(null);setN('');setE('');setA('');setCat('')};
  const tx=1+db.settings.tax/100;
  const fw=kg=>unit==='kg'?(+kg.toFixed(2)).toLocaleString('en-IN')+' kg':(+(kg/kpm).toFixed(2)).toLocaleString('en-IN')+' mound';
  const stat=c=>{const l=invs.filter(i=>i.cid===c.id);return{l,n:l.length,kg:l.reduce((a,i)=>a+netKg(i,kpm),0),amt:l.reduce((a,i)=>a+sub(i,kpm)*tx,0)}};
  const rows=db.customers.filter(c=>!fc||c.cat===fc).map(c=>({c,...stat(c)}));
  const T=rows.reduce((a,r)=>({n:a.n+r.n,kg:a.kg+r.kg,amt:a.amt+r.amt}),{n:0,kg:0,amt:0});
  const sc=sel&&rows.find(r=>r.c.id===sel);
  const F=(l,el)=><div><label>{l}</label>{el}</div>;
  return <><div className="panel"><h2>{ed?'Edit customer':'Customers'}</h2>
    {canAdd&&<div style={{display:'grid',gap:10,maxWidth:420,marginBottom:14}}>
      {F('Name',<input style={{width:'100%'}} value={n} onChange={x=>setN(x.target.value)}/>)}
      {F('Email',<input style={{width:'100%'}} value={e} onChange={x=>setE(x.target.value)}/>)}
      {F('Address',<input style={{width:'100%'}} value={a} onChange={x=>setA(x.target.value)}/>)}
      {F('Category',<select style={{width:'100%'}} value={cat} onChange={x=>setCat(x.target.value)}><option value="">Category</option>{(db.cats.customer||[]).map(k=><option key={k} value={k}>{k}</option>)}</select>)}
      <div><button className="btn" onClick={()=>{if(!n.trim())return;onAdd({id:ed||Date.now(),name:n.trim(),email:e.trim(),address:a.trim(),cat});clr()}}>{ed?'Save changes':'Add customer'}</button>{ed&&<button className="btn ghost" style={{marginLeft:8}} onClick={clr}>Cancel</button>}</div>
    </div>}
    <div className="row"><select aria-label="Filter by category" style={{flex:'0 1 260px'}} value={fc} onChange={x=>setFc(x.target.value)}><option value="">All categories</option>{(db.cats.customer||[]).map(k=><option key={k} value={k}>{k}</option>)}</select></div>
    <div className="wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Address</th><th>Category</th><th>Invoices</th><th>Net weight</th><th>Total</th><th></th></tr></thead><tbody>
      {rows.map(({c,n,kg,amt})=><tr key={c.id}><td><b>{c.name}</b></td><td>{c.email||'\u2014'}</td><td style={{whiteSpace:'normal',minWidth:140}}>{c.address||'\u2014'}</td><td>{c.cat||'\u2014'}</td><td>{n}</td><td>{fw(kg)}</td><td>{money(amt)}</td>
        <td><button className="btn ghost sm" onClick={()=>setSel(sel===c.id?null:c.id)}>{sel===c.id?'Hide invoices':'Invoices'}</button> {canAdd&&<button className="btn ghost sm" onClick={()=>{setEd(c.id);setN(c.name);setE(c.email||'');setA(c.address||'');setCat(c.cat||'');window.scrollTo({top:0,behavior:'smooth'})}}>Edit</button>} {canAdd&&(cf===c.id?<><button className="btn sm" style={{background:'var(--over)'}} onClick={()=>{onDel(c.id);setCf(null);if(sel===c.id)setSel(null);if(ed===c.id)clr()}}>Confirm delete</button> <button className="btn ghost sm" onClick={()=>setCf(null)}>Cancel</button></>:<button className="btn ghost sm" onClick={()=>setCf(c.id)}>Delete</button>)}</td></tr>)}
    </tbody><tfoot><tr style={{fontWeight:600}}><td colSpan={4}>Total ({rows.length} customers)</td><td>{T.n}</td><td>{fw(T.kg)}</td><td>{money(T.amt)}</td><td></td></tr></tfoot></table></div></div>
    {sc&&<div className="panel"><h2>Invoices – {sc.c.name}</h2>
      {sc.l.length?<div className="wrap"><table><thead><tr><th>No.</th><th>Date</th><th>Net weight</th><th>Total</th></tr></thead><tbody>
        {sc.l.map(i=><tr key={i.id}><td>#{i.id}</td><td>{fmtDate(i.date)}</td><td>{fw(netKg(i,kpm))}</td><td>{money(sub(i,kpm)*tx)}</td></tr>)}
      </tbody><tfoot><tr style={{fontWeight:600}}><td colSpan={2}>Total ({sc.n} invoices)</td><td>{fw(sc.kg)}</td><td>{money(sc.amt)}</td></tr></tfoot></table></div>:<p style={{color:'var(--mute)'}}>No invoices for this customer yet.</p>}
    </div>}</>;
}
