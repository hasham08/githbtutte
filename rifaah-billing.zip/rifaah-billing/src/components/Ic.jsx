import { ICONS } from '../lib.js'

export default function Ic({n}){return <svg className="ic" viewBox="0 0 24 24" aria-hidden="true" dangerouslySetInnerHTML={{__html:ICONS[n]||''}}/>}
