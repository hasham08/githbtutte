import Ic from './Ic'

export default function InvTable({invs,money,total,cname,isAdmin,onDelete,wt,ename,sname,onView,canPrint,wtAll,canDel}){
  if(!invs.length) return <p style={{color:'var(--mute)'}}>No invoices yet. Create one from “New invoice”.</p>;
  return <div className="wrap"><table><thead><tr><th>No.</th><th>Customer</th><th>Supplier</th><th>Created by</th><th>Category</th><th>Product · Variety</th><th>Qty</th><th>Weight</th><th>Total</th><th></th></tr></thead><tbody>
    {invs.map(i=><tr key={i.id}><td>#{i.id}</td><td>{cname(i.cid)}</td><td>{sname(i.sid)}</td><td>{ename(i.by)}</td><td>{[...new Set(i.items.map(x=>x.cat).filter(Boolean))].join(', ')||'—'}</td><td style={{whiteSpace:'normal',minWidth:160}}>{i.items.map(x=>x.pn?x.pn+' · '+x.vr:x.d).join(', ')}</td><td>{i.items.reduce((a,x)=>a+(+x.q||0),0)}</td><td>{wt(i)}</td><td>{money(total(i))}</td>
      <td style={{textAlign:'right'}}>
        {canPrint&&<button className="btn ghost sm" onClick={()=>onView(i.id)}><Ic n="eye"/>Preview</button>}{' '}
        {canDel&&onDelete&&<button className="btn ghost sm" onClick={()=>onDelete(i.id)}>Delete</button>}
        
      </td></tr>)}
  </tbody><tfoot><tr style={{fontWeight:600}}><td colSpan={6}>Total ({invs.length} invoices)</td><td>{invs.reduce((a,i)=>a+i.items.reduce((b,x)=>b+(+x.q||0),0),0)}</td><td>{wtAll(invs)}</td><td>{money(invs.reduce((a,i)=>a+total(i),0))}</td><td></td></tr></tfoot></table></div>;
}
