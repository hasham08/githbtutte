import { useState } from 'react'
import { calc, sub, netKg, fmtDate } from '../lib.js'
import FOOTLOGOS from '../assets/footer-logos.webp'
import LOGO from '../assets/logo.webp'
import Ic from './Ic'

export default function InvoiceSheet({inv,db,money,kpm,cname,ename,onClose}){
  const [hint,setHint]=useState('');const alert2=m=>setHint(m);
  if(!inv)return null;
  const s=sub(inv,kpm),tax=s*db.settings.tax/100;
  const cu=db.customers.find(c=>c.id===inv.cid)||{};
  const su=inv.sid?db.suppliers.find(x=>x.id===inv.sid):null;
  const f=n=>(+n.toFixed(2)).toLocaleString('en-IN');
  const msg=['Invoice #'+inv.id+' \u2013 '+db.settings.company,'Date: '+fmtDate(inv.date),cu.name?'Bill to: '+cu.name:null,su?'Supplier: '+su.name:null,'']
    .concat(inv.items.map(x=>{const c=calc(x,kpm);return '\u2022 '+(x.pn||x.d)+(x.vr?' ('+x.vr+')':'')+': '+(x.q||0)+' bag, net '+f(c.net)+' kg = '+f(c.m)+' mound @ '+money(+x.rate||0)+' = '+money(c.amt)}))
    .concat(['','Total net weight: '+f(netKg(inv,kpm))+' kg = '+f(netKg(inv,kpm)/kpm)+' mound','SUBTOTAL: '+money(s),'TAX ('+db.settings.tax+'%): '+money(tax),'GRAND TOTAL: '+money(s+tax)]).filter(l=>l!==null).join('\n');
  const mailTo=(cu.email||(su&&su.email)||'');
  const waHref='https://wa.me/?text='+encodeURIComponent(msg);
  const mailHref='mailto:'+mailTo+'?subject='+encodeURIComponent('Invoice #'+inv.id+' \u2013 '+db.settings.company)+'&body='+encodeURIComponent(msg);
  return <div className="ov"><div className="noprint bar"><button className="ibtn" title="Print" aria-label="Print" onClick={()=>window.print()}><Ic n="print"/></button><b style={{color:'#333'}}>Invoice preview</b><span style={{display:'flex',gap:6}}><a className="ibtn" title="Share on WhatsApp" aria-label="Share on WhatsApp" href={waHref} target="_blank" rel="noopener noreferrer"><Ic n="wa"/></a><a className="ibtn" title="Send by email" aria-label="Send by email" href={mailHref} target="_blank" rel="noopener noreferrer"><Ic n="mail"/></a><button className="ibtn" title="Save as PDF" aria-label="Save as PDF" onClick={()=>{alert2('In the print window, choose \u201cSave as PDF\u201d as the printer.');window.print()}}><Ic n="pdf"/></button><button className="ibtn" title="Close" aria-label="Close invoice" onClick={onClose}><Ic n="x"/></button></span></div>
    {hint&&<div className="noprint" style={{maxWidth:820,margin:'0 auto 8px',color:'#333',fontSize:13}}>{hint}</div>}
    <div className={'sheet'+(inv.items.length>10?' dense':'')}>
      <div className="sh-head"><img src={LOGO} alt="Rifaah Group Pakistan logo"/><div><h1 style={{margin:0,textTransform:'uppercase'}}>{String(db.settings.company).replace(/[().]/g,'').replace(/\s+/g,' ').trim()}</h1><div style={{fontWeight:600}}>{db.settings.address||'Near New Grain Market RYK'}</div></div></div>
      <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:16,flexWrap:'wrap',marginBottom:6}}><b style={{fontSize:18}}>INVOICE #{inv.id}</b><span>Date: {fmtDate(inv.date)}</span></div>
      <div style={{display:'flex',gap:'12px 40px',flexWrap:'wrap',marginBottom:6}}>
        {inv.cid&&cu.name?<div><b>Bill to:</b> {cu.name}<br/>Address: {cu.address||'\u2014'}<br/>Email: {cu.email||'\u2014'}</div>:null}
        {su?<div><b>Supplier:</b> {su.name}<br/>Address: {su.address||'\u2014'}<br/>Email: {su.email||'\u2014'}</div>:null}
      </div>
      <div style={{marginBottom:12}}>Employee: {ename(inv.by)}</div>
      <div className="wrap"><table><thead><tr><th>Product</th><th>Variety</th><th className="r">Qty (Bag/Boris)</th><th className="r">Weight (kg)</th><th className="r">Cut (kg)</th><th className="r">Net (kg)</th><th className="r">Net (mound)</th><th className="r">Rate / mound</th><th className="r">Amount</th></tr></thead><tbody>
        {inv.items.map((x,k)=>{const c=calc(x,kpm);return <tr key={k}><td>{x.pn||x.d}</td><td>{x.vr||'—'}</td><td className="r">{x.q||0}</td><td className="r">{f(+x.kg||0)}</td><td className="r">{f(c.cutKg)}</td><td className="r">{f(c.net)}</td><td className="r">{f(c.m)}</td><td className="r">{money(+x.rate||0)}</td><td className="r">{money(c.amt)}</td></tr>})}
      </tbody><tfoot><tr style={{fontWeight:600}}><td colSpan={2} style={{textAlign:'left'}}>TOTAL</td><td className="r">{inv.items.reduce((a,x)=>a+(+x.q||0),0)}</td><td className="r">{f(inv.items.reduce((a,x)=>a+(+x.kg||0),0))}</td><td className="r">{f(inv.items.reduce((a,x)=>a+calc(x,kpm).cutKg,0))}</td><td className="r">{f(netKg(inv,kpm))}</td><td className="r">{f(netKg(inv,kpm)/kpm)}</td><td></td><td className="r">{money(s)}</td></tr></tfoot></table></div>
      <div style={{marginTop:10,fontWeight:600}}>Total net weight: {f(netKg(inv,kpm))} kg = {f(netKg(inv,kpm)/kpm)} mound <span style={{fontWeight:400}}>({kpm} kg = 1 mound)</span></div>
      <div style={{maxWidth:360,marginLeft:'auto',marginTop:18,display:'grid',gap:10}}>
        <div style={{display:'flex',justifyContent:'space-between',gap:16}}><span>SUBTOTAL</span><span>{money(s)}</span></div>
        <div style={{display:'flex',justifyContent:'space-between',gap:16}}><span>TAX ({db.settings.tax}%)</span><span>{money(tax)}</span></div>
        <div style={{display:'flex',justifyContent:'space-between',gap:16,borderTop:'1px solid #0e7c66',paddingTop:10,fontSize:17,fontWeight:700}}><span>GRAND TOTAL</span><span>{money(s+tax)}</span></div>
      </div>
      <div className="ft"><b>{db.settings.company}</b><br/>Thank you for your business. This is a computer-generated invoice.<br/><img className="ft-logos" style={{maxWidth:(db.settings.footLogo||300)+'px'}} src={FOOTLOGOS} alt="Rifaah Group, Swiss Military and Zulfiqar Seeds logos"/></div>
    </div></div>;
}
