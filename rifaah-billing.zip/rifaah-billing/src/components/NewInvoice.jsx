import { useState } from 'react'
import { calc, todayISO } from '../lib.js'

export default function NewInvoice({db,onSave,money,fixed,kpm,canCust=true,canSupp=true,canNewCust=false,canNewSupp=false,onNewCust,onNewSupp}){
  const [nw,setNw]=useState(null),[nn,setNn]=useState(''),[nc,setNc]=useState('');
  const [cid,setCid]=useState(canCust?(fixed||db.customers[0]?.id||0):0);
  const [sid,setSid]=useState(canCust?'':String(db.suppliers[0]?.id||''));
  const blank={d:'',tx:'',q:0,kg:0,cut:0,cu:'kg',rate:0};
  const [items,setItems]=useState([blank]);
  const set=(n,k,v)=>setItems(a=>a.map((x,i)=>i===n?{...x,[k]:v}:x));
  const s=items.reduce((a,x)=>a+calc(x,kpm).amt,0), tax=s*db.settings.tax/100;
  const save=()=>{const clean=items.filter(x=>x.d.trim()&&x.kg>0);if(!clean.length)return;if(canCust&&!cid)return;if(!canCust&&!sid)return;
    const nid=Math.max(1000,...db.invoices.map(i=>i.id))+1;
    onSave({id:nid,cid:+cid,sid:sid?+sid:0,date:todayISO(),status:'Paid',items:clean})};
  return <div className="panel"><h2>New invoice</h2>
    <div style={{display:'grid',gap:10,maxWidth:420,marginBottom:10}}>{canCust&&<div><label>Customer</label><select style={{width:'100%'}} disabled={!!fixed} value={cid} onChange={e=>setCid(e.target.value)}>{db.customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div>}
    {canSupp&&<div><label>{canCust?'Supplier (optional)':'Supplier'}</label><select style={{width:'100%'}} value={sid} onChange={e=>setSid(e.target.value)}>{canCust&&<option value="">No supplier</option>}{db.suppliers.map(x=><option key={x.id} value={x.id}>{x.name}{x.cat?' · '+x.cat:''}</option>)}</select></div>}
    </div>
    {((canCust&&canNewCust)||(canSupp&&canNewSupp))&&<div className="row" style={{alignItems:'center'}}>
      {canCust&&canNewCust&&nw!=='customer'&&<button type="button" className="btn ghost sm" onClick={()=>{setNw('customer');setNn('');setNc('')}}>+ Add new customer</button>}
      {canSupp&&canNewSupp&&nw!=='supplier'&&<button type="button" className="btn ghost sm" onClick={()=>{setNw('supplier');setNn('');setNc('')}}>+ Add new supplier</button>}
      {nw&&<><input placeholder={nw==='customer'?'New customer name':'New supplier name'} aria-label="New name" value={nn} onChange={e=>setNn(e.target.value)} style={{flex:'2 1 180px'}}/>
        <select aria-label="Category" value={nc} onChange={e=>setNc(e.target.value)} style={{flex:'1 1 120px'}}><option value="">Category</option>{(db.cats[nw]||[]).map(k=><option key={k} value={k}>{k}</option>)}</select>
        <button type="button" className="btn sm" onClick={()=>{if(!nn.trim())return;if(nw==='customer'){setCid(onNewCust(nn.trim(),nc))}else{setSid(String(onNewSupp(nn.trim(),nc)))}setNw(null);setNn('');setNc('')}}>Save and select</button>
        <button type="button" className="btn ghost sm" onClick={()=>setNw(null)}>Cancel</button></>}
    </div>}
    {items.map((x,n)=><div className="row" key={n}>
      <select style={{flex:'3 1 220px'}} aria-label="Product" value={x.pid||''} onChange={e=>{const p=db.products.find(q=>String(q.id)===e.target.value);setItems(a=>a.map((y,i)=>i===n?{...y,pid:p?p.id:'',cat:p?p.cat:'',pn:p?p.name:'',vr:p?p.variety:'',d:p?p.name+' – '+p.variety:''}:y))}}><option value="">Select product (category · name · variety)</option>{db.products.map(p=><option key={p.id} value={p.id}>{p.cat} · {p.name} · {p.variety}</option>)}</select>
      <input type="number" min="0" placeholder="Weight (kg)" aria-label="Weight in kg" value={x.kg||''} onChange={e=>set(n,'kg',+e.target.value)}/>
      <input type="number" min="0" placeholder="Cut (optional)" aria-label="Weight cut" value={x.cut||''} onChange={e=>set(n,'cut',+e.target.value)}/>
      <select aria-label="Cut unit" value={x.cu||'kg'} onChange={e=>set(n,'cu',e.target.value)}><option value="kg">cut in kg</option><option value="mound">cut in mound</option></select>
      <input type="number" min="0" placeholder="Rate per mound (PKR)" aria-label="Rate" value={x.rate||''} onChange={e=>set(n,'rate',+e.target.value)}/>
      <input placeholder="Note (text)" aria-label="Note" value={x.tx||''} onChange={e=>set(n,'tx',e.target.value)}/>
      <input type="number" min="0" placeholder="Bags" aria-label="Bags" value={x.q||''} onChange={e=>set(n,'q',+e.target.value)}/>
      
      <div style={{flex:'1 1 100%',color:'var(--mute)',fontSize:13}}>{+(+x.kg||0).toFixed(2)} kg − cut {+calc(x,kpm).cutKg.toFixed(2)} kg = net {+calc(x,kpm).net.toFixed(2)} kg = {calc(x,kpm).m.toFixed(2)} mound · {money(calc(x,kpm).amt)}</div>
    </div>)}
    <button className="btn ghost sm" onClick={()=>setItems(a=>[...a,{...blank}])}>Add item</button>
    <div style={{maxWidth:360,marginLeft:'auto',marginTop:14,display:'grid',gap:10}}>
      <div style={{display:'flex',justifyContent:'space-between',gap:16}}><span>SUBTOTAL</span><span>{money(s)}</span></div>
      <div style={{display:'flex',justifyContent:'space-between',gap:16}}><span>TAX ({db.settings.tax}%)</span><span>{money(tax)}</span></div>
      <div style={{display:'flex',justifyContent:'space-between',gap:16,borderTop:'1px solid var(--line)',paddingTop:10,fontSize:18,fontWeight:600}}><span>GRAND TOTAL</span><span>{money(s+tax)}</span></div>
    </div>
    <div className="tot"><button className="btn" onClick={save}>Create invoice</button></div></div>;
}
