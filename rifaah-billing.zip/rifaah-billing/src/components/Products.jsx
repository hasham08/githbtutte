import { useState } from 'react'

export default function Products({db,onSave,onDel,canEdit=true,canDel=true}){
  const [ed,setEd]=useState(null),[cf,setCf]=useState(null),[c,setC]=useState(''),[n,setN]=useState(''),[v,setV]=useState('');
  const clr=()=>{setEd(null);setC('');setN('');setV('')};
  return <div className="panel"><h2>{canEdit?(ed?'Edit product':'Add product'):'Products'}</h2>
    {canEdit&&<div className="row"><input placeholder="Category (e.g. Grain)" list="cats" value={c} onChange={x=>setC(x.target.value)}/><datalist id="cats">{[...new Set(db.products.map(p=>p.cat))].map(k=><option key={k} value={k}/>)}</datalist>
    <input placeholder="Product name" value={n} onChange={x=>setN(x.target.value)}/><input placeholder="Variety name" value={v} onChange={x=>setV(x.target.value)}/>
    <button className="btn" onClick={()=>{if(!c.trim()||!n.trim())return;onSave({id:ed||Date.now(),cat:c.trim(),name:n.trim(),variety:v.trim()});clr()}}>{ed?'Save changes':'Add product'}</button>{ed&&<button className="btn ghost" onClick={clr}>Cancel</button>}</div>}
    <div className="wrap"><table><thead><tr><th>Category</th><th>Product</th><th>Variety</th><th></th></tr></thead><tbody>
      {db.products.map(p=><tr key={p.id}><td>{p.cat}</td><td>{p.name}</td><td>{p.variety}</td><td>{canEdit&&<button className="btn ghost sm" onClick={()=>{setEd(p.id);setC(p.cat);setN(p.name);setV(p.variety);setCf(null)}}>Edit</button>} {cf===p.id&&canDel?<><button className="btn sm" style={{background:'var(--over)'}} onClick={()=>{onDel(p.id);setCf(null)}}>Confirm delete</button> <button className="btn ghost sm" onClick={()=>setCf(null)}>Cancel</button></>:canDel&&<button className="btn ghost sm" onClick={()=>setCf(p.id)}>Delete</button>}</td></tr>)}
    </tbody></table></div>
    <p style={{color:'var(--mute)',fontSize:13,margin:'10px 0 0'}}>Editing or deleting a product does not change invoices already created.</p></div>;
}
