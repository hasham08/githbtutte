import { useState } from 'react'

export default function ResetAll({onReset}){
  const [mode,setMode]=useState('empty'),[t,setT]=useState(''),[er,setEr]=useState('');
  const go=()=>{if(t.trim().toUpperCase()!=='RESET'){setEr('Type the word RESET in the box first, then press the button.');return}setEr('');onReset(mode);setT('')};
  return <div className="panel" style={{borderColor:'var(--over)'}}><h2>Reset all software</h2>
    <p style={{margin:'0 0 10px',color:'var(--mute)'}}>This erases every invoice, customer, supplier, product, category and employee, and sets Settings back to default. Your admin username and password are kept. It cannot be undone.</p>
    <div className="row"><div style={{flex:'1 1 220px'}}><label>After reset</label><select style={{width:'100%'}} value={mode} onChange={e=>setMode(e.target.value)}><option value="empty">Start empty (no data)</option><option value="sample">Load sample data</option></select></div>
    <div style={{flex:'1 1 220px'}}><label>Type RESET to confirm</label><input style={{width:'100%'}} placeholder="RESET" value={t} onChange={e=>{setT(e.target.value);setEr('')}} autoComplete="off"/></div></div>
    {er&&<p role="alert" style={{color:'var(--over)',margin:'0 0 10px'}}>{er}</p>}
    <button className="btn" style={{background:'var(--over)',color:'#fff'}} onClick={go}>Reset all software</button></div>;
}
