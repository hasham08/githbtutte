import { useState } from 'react'

export default function Settings({s,onSave}){
  const [v,setV]=useState(s);
  const f=(k,val)=>setV(o=>({...o,[k]:val}));
  return <div className="panel"><h2>Customise your software</h2>
    <div className="row"><div style={{flex:'1 1 200px'}}><label>Company name</label><input style={{width:'100%'}} value={v.company} onChange={e=>f('company',e.target.value)}/></div>
    <div style={{flex:'1 1 200px'}}><label>Company address (shown on invoice)</label><input style={{width:'100%'}} value={v.address===undefined?'Near New Grain Market RYK':v.address} onChange={e=>f('address',e.target.value)}/></div>
    <div style={{flex:'1 1 200px'}}><label>Invoice footer logos size: {v.footLogo||300}px</label><input style={{width:'100%'}} type="range" min="120" max="520" step="10" value={v.footLogo||300} onChange={e=>f('footLogo',+e.target.value)}/></div>
    <div style={{flex:'1 1 100px'}}><label>Currency symbol</label><input style={{width:'100%'}} value={v.currency} onChange={e=>f('currency',e.target.value)}/></div>
    <div style={{flex:'1 1 100px'}}><label>Kg per mound</label><input style={{width:'100%'}} type="number" min="1" value={v.kpm} onChange={e=>f('kpm',+e.target.value)}/></div>
    <div style={{flex:'1 1 100px'}}><label>Tax / GST %</label><input style={{width:'100%'}} type="number" min="0" value={v.tax} onChange={e=>f('tax',+e.target.value)}/></div>
    <div style={{flex:'1 1 100px'}}><label>Brand colour</label><input style={{width:'100%',padding:2,height:38}} type="color" value={v.brand} onChange={e=>f('brand',e.target.value)}/></div></div>
    <button className="btn" onClick={()=>onSave(v)}>Save settings</button></div>;
}
