export const KEY='billdesk-v4';
export const seed={
  settings:{company:'Rifaah Crop Sciences (Pvt) Ltd.',address:'Near New Grain Market RYK',footLogo:300,currency:'PKR ',tax:0,brand:'#0e7c66',kpm:40},
  products:[{id:1,cat:'Grain',name:'Wheat',variety:'Akbar-19'},{id:2,cat:'Grain',name:'Rice',variety:'Super Basmati'},{id:3,cat:'Grain',name:'Maize',variety:'Hybrid'},{id:4,cat:'Sugar',name:'Sugar',variety:'Grade A'}],
  printMig:true,csMig:true,paidMig:true,
  cats:{customer:['Dealer','Farmer','Distributor'],supplier:['Raw material','Packaging','Transport']},
  admin:{username:'admin',password:'admin123'},
  suppliers:[{id:1,name:'Punjab Grain Mills',phone:'0300-1234567',email:'info@punjabgrain.example',address:'Industrial Area, Faisalabad',cat:'Raw material'},{id:2,name:'Lahore Packaging Co.',phone:'0321-7654321',email:'sales@lhrpack.example',address:'Kot Lakhpat, Lahore',cat:'Packaging'}],
  employees:[{id:1,name:'Ali Raza',email:'ali@acme.example',username:'ali',password:'ali123',perms:['inv','inv.add','inv.cust','inv.supp','inv.print','cus','cus.add','sup','sup.add']},{id:2,name:'Sana Khan',email:'sana@acme.example',username:'sana',password:'sana123',perms:['inv','inv.add','inv.cust','inv.supp','inv.print','cus','cus.add']}],
  customers:[{id:1,name:'Ravi Traders',email:'ravi@example.com',address:'Main Bazaar, Multan',cat:'Dealer'},{id:2,name:'Sunrise Clinic',email:'office@sunrise.example',address:'Model Town, Lahore',cat:'Distributor'},{id:3,name:'Meena Boutique',email:'meena@example.com',address:'Gulberg, Lahore',cat:'Farmer'}],
  invoices:[
    {id:1001,by:1,cid:1,sid:1,date:'2026-10-02',due:'2026-10-16',status:'Paid',items:[{d:'Wheat – Akbar-19',pn:'Wheat',vr:'Akbar-19',cat:'Grain',tx:'50 kg bags',q:40,kg:2000,cut:20,rate:4000}]},
    {id:1002,by:2,cid:2,sid:2,date:'2026-10-12',due:'2026-10-26',status:'Paid',items:[{d:'Rice – Super Basmati',pn:'Rice',vr:'Super Basmati',cat:'Grain',kg:1200,cut:0,rate:9500},{d:'Maize – Hybrid',pn:'Maize',vr:'Hybrid',cat:'Grain',kg:800,cut:10,rate:4400,cu:'kg'}]},
    {id:1003,by:1,cid:1,date:'2026-10-28',due:'2026-11-11',status:'Paid',items:[{d:'Sugar – Grade A',pn:'Sugar',vr:'Grade A',cat:'Sugar',kg:500,cut:0,rate:6000,cu:'kg'}]},
    {id:1004,by:2,cid:3,date:'2026-11-01',due:'2026-11-15',status:'Paid',items:[{d:'Wheat – Akbar-19',pn:'Wheat',vr:'Akbar-19',cat:'Grain',kg:4000,cut:40,rate:3900}]}
  ]};
export function load(){try{const s=localStorage.getItem(KEY);if(s){const d=JSON.parse(s);if(!d.cats)d.cats=seed.cats;if(!d.products)d.products=seed.products;if(!d.printMig){d.employees.forEach(m=>{if((m.perms||[]).includes('invoice')&&!m.perms.includes('print'))m.perms.push('print')});d.printMig=true}d.employees.forEach(m=>{m.perms=migratePerms(m.perms).filter(k=>k!=='inv.paid')});if(!d.csMig){d.employees.forEach(m=>{if(m.perms.includes('inv.add')){['inv.cust','inv.supp'].forEach(k=>{if(!m.perms.includes(k))m.perms.push(k)})}});d.csMig=true}if(!d.paidMig){d.invoices.forEach(i=>{i.status='Paid'});d.paidMig=true}return d}}catch(e){}return seed}
export const calc=(x,k)=>{const cutKg=x.cu==='mound'?(+x.cut||0)*k:(+x.cut||0);const net=Math.max(0,(+x.kg||0)-cutKg);const m=net/k;return{net,m,cutKg,amt:m*(+x.rate||0)}};
export const sub=(i,k)=>i.items.reduce((a,x)=>a+calc(x,k).amt,0);
export const fmtDate=d=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d||'');return m?m[3]+'/'+m[2]+'/'+m[1]:(d||'')};
export const todayISO=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
export const netKg=(i,k)=>i.items.reduce((a,x)=>a+calc(x,k).net,0);
export const PERM_GROUPS=[
  {page:'inv',label:'Invoices',acts:[['inv.add','Create invoices'],['inv.cust','  ↳ for Customers'],['inv.supp','  ↳ for Suppliers'],['inv.print','Print / PDF'],['inv.del','Delete invoices'],['inv.all','See all invoices']]},
  {page:'cus',label:'Customers',acts:[['cus.add','Add customers']]},
  {page:'sup',label:'Suppliers',acts:[['sup.add','Add suppliers']]},
  {page:'prod',label:'Products',acts:[['prod.edit','Add / edit products'],['prod.del','Delete products']]},
  {page:'cat',label:'Categories',acts:[['cat.cust','Customer categories'],['cat.supp','Supplier categories']]}];
export const PERMS=PERM_GROUPS.flatMap(g=>[[g.page,g.label+' page'],...g.acts]);
export const migratePerms=p=>{
  const o=['invoice','customers','suppliers','markpaid','custcat','suppcat','print'];const s=new Set(p||[]);
  if(![...s].some(k=>o.includes(k)))return [...s];
  const r=new Set([...s].filter(k=>!o.includes(k)));
  if(s.has('invoice')){r.add('inv');r.add('inv.add');r.add('inv.cust');r.add('inv.supp')}
  if(s.has('print')){r.add('inv');r.add('inv.print');if(!s.has('invoice'))r.add('inv.all')}
  if(s.has('customers')){r.add('cus');r.add('cus.add')}
  if(s.has('suppliers')){r.add('sup');r.add('sup.add')}
  if(s.has('custcat')){r.add('cat');r.add('cat.cust')}
  if(s.has('suppcat')){r.add('cat');r.add('cat.supp')}
  return [...r];
};
export const ICONS={
  dash:'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  inv:'<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h8M9 17h8"/>',
  new:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  cus:'<circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-6 7-6s7 2 7 6"/><path d="M16 4a4 4 0 0 1 0 8M19 15c2 1 3 3 3 6"/>',
  sup:'<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  prod:'<path d="M12 3l9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/>',
  cat:'<path d="M3 12l9-9h9v9l-9 9z"/><circle cx="16" cy="8" r="1.5"/>',
  emp:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-6 8-6s8 2 8 6"/>',
  set:'<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.5-2.3 1a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.6a7 7 0 0 0-2 1.2l-2.3-1-2 3.5 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.5 2.3-1a7 7 0 0 0 2 1.2L10 21h4l.6-2.6a7 7 0 0 0 2-1.2l2.3 1 2-3.5-2-1.5c.1-.4.1-.8.1-1.2z"/>',
  out:'<path d="M9 3H4v18h5M16 8l4 4-4 4M20 12H9"/>',
  print:'<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="1"/><path d="M7 14h10v7H7z"/>',
  pdf:'<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/><path d="M12 11v6M9 14l3 3 3-3"/>',
  eye:'<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  wa:'<path d="M3 21l1.6-4.6A8.5 8.5 0 1 1 8 19.6z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.5-1.8-1.3-2.3-2.3l.8-1-1-2z"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>'
};
